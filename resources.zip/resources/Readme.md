# Kickstarting with Excel

## Overview of Project
Navigate a dataset to understand fundraising campaigns for theather and plays in the US. 
### Purpose
Analyze a set of data to help Louise understand the trends surrounding tfunderaising campaigns for theathers and plays in the US and GB. 
## Analysis and Challenges
Drive the information that's relevant to Louise's scope in this project helped provide a better analysis of the trends, understand how donations have factored in the success, failure, and canceled campaigns across the board. The Key challenges envountered in this analysis were related to the final pivot table and the countifs function. I struggled with the syntax in excel;leading to no trusting the data in my analysis.
### Analysis of Outcomes Based on Launch Date
Campaigns launch in May/June have a higher success rate than those lunch in months prior. Plus, campaigns launched in November /december have a tendency to fail. However, canceled campain have been constant in across the board and by months. The only outlier occuers in January with 7 campaigns canceled.
### Analysis of Outcomes Based on Goals
The data suggests that successful campaigns tend to have a goal less than $1000 and no more than $5000. Failed campaigns have a higher percentage based on goals in this category. Part of the challenge with this approach is the inability to find the #number of canceled campaigns based on goals. Hence, the reason why my answer isn't trustworthy for this question. 
### Challenges and Difficulties Encountered
Beside the inability to course correct in the "outcome based goals" tab, the biggest challenge was navigating the data and making sure the right information is used to drive the analysis.
## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date?
The outcomes by launch dates provide a full picture of successful campaign in the theather category. The ability to filter the resuls by country, or parents category helps narrow the analysis for Louise. Additional filders can be added to support the analysis by filtering by subcategory as well. Plus, having a timeline that confirms which month is more successful to launch a campaign is crucial to any person driving this research.
- What can you conclude about the Outcomes based on Goals?
The outcomes based approach is limited and does not tell the entire story for this analysis. the range of donations in this case tend to lean towards failed campaigns - i.e., higher percentage than successful ones.
- What are some limitations of this dataset?
The dataset didn't have too many limitations - however, it helped to format some cells at the biginning of the exercise to have a clearer picture of the task at hand.
- What are some other possible tables and/or graphs that we could create?
Box & Whiskers, pivot tables, stacked column, line graphs
